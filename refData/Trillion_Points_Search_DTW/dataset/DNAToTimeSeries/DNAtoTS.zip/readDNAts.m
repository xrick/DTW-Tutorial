%%% code to read time series of a DNA
clear;
clc;
warning off;

fid = fopen('TS_chr.txt','rb');
ts= fread(fid,inf,'int');
fclose(fid);